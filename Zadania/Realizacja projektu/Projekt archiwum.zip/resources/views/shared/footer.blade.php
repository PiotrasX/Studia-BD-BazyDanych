<div class="content mb-5"></div>
<footer class="container-fluid bg-color-gray">
    <div class="row text-center justify-content-center pt-3">
        <div class="col-4 col-sm-3 col-xl-2">
            <a href="https://www.facebook.com/fhuDOMropczyce" target="_blank">
                <img src="{{ asset('img/facebook_logo.png') }}" alt="Facebook" class="img-fluid img-max-size-48">
            </a>
        </div>
        <div class="col-4 col-sm-3 col-xl-2">
            <a href="https://maps.app.goo.gl/C6ZmEdjJeGysjy9GA" target="_blank">
                <img src="{{ asset('img/mapy_logo.png') }}" alt="Mapy google" class="img-fluid img-max-size-48">
            </a>
        </div>
        <div class="col-4 col-sm-3 col-xl-2">
            <a href="https://github.com/PiotrasX/Bazy-Danych" target="_blank">
                <img src="{{ asset('img/github_logo.png') }}" alt="Github" class="img-fluid img-max-size-48">
            </a>
        </div>
    </div>
    <div class="row text-center pt-3">
        <p>&copy; Komis samochodowy &ndash; 2024</p>
    </div>
</footer>
